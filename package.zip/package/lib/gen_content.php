<?php
	include(__DIR__ .'/custom.php');
	function vars($google){
        $info=new stdClass;
        $info->status=false;
        $info->random_date=date('d/m/Y',time()-86400*rand(0,360));
        $info->rand1_5=mt_rand(100,500)/100;
        $info->rand10_30=rand(10,30);
        $info->relates_lists=implode(', ',$google->relates);
        $info->keyword=$google->keyword;
        $info->title=$info->keyword;
        
        return $info;
    }
    function details_gen_content($var,$config,$wp_name='site1'){
    	$info=new stdClass;
	    $info->status=false;

	    //parse top content
	    $details_top_content=$config['wp']['wp_post_template'][$wp_name]['details_top_content'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['details_top_content'],$match);
	    foreach ($match[1] as $m){
	        $details_top_content=str_replace('{'.$m.'}',$var->{$m},$details_top_content);
	    }
	    $details_top_content=html_entity_decode($details_top_content);
	    // echo $details_top_content;

	    $details_bottom_content=$config['wp']['wp_post_template'][$wp_name]['details_bottom_content'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['details_bottom_content'],$match);
	    foreach ($match[1] as $m){
	        $details_bottom_content=str_replace('{'.$m.'}',$var->{$m},$details_bottom_content);
	    }
	    $details_bottom_content=html_entity_decode($details_bottom_content);

	    $details_body=$config['wp']['wp_post_template'][$wp_name]['details_body'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['details_body'],$match);
	    foreach ($match[1] as $m){
	        $details_body=str_replace('{'.$m.'}',$var->{$m},$details_body);
	    }
	    $details_body=html_entity_decode($details_body);


	    preg_match_all('/\[(.*?)\]/is',$config['wp']['wp_post_template'][$wp_name]['details_content'],$match);
	    $details_content=$config['wp']['wp_post_template'][$wp_name]['details_content'];
	    foreach ($match[1] as $m){
	        if (isset($$m)){
	            $details_content=str_replace('['.$m.']',$$m,$details_content);
	        }
	    }
	    // $info->content=$content;
	    return $details_content;
    }
	function gen_content($google,$config,$wp_name='site1') {
		$php=new QuyetPHP();
	    $info=new stdClass;
	    $info->status=false;

	    //parse top content
	    $top_content=$config['wp']['wp_post_template'][$wp_name]['top_content'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['top_content'],$match);
	    foreach ($match[1] as $m){
	        $top_content=str_replace('{'.$m.'}',$google->{$m},$top_content);
	    }
	    $top_content=html_entity_decode($top_content);

	    preg_match_all('/(.*?)__func__(.*?)__endfunc__(.*)/is',$top_content,$match);
	    // $rep='';
	    for ($i=0;$i<count($match[2]);$i++){
	    	if (isset($match[2][$i])){
		    	$_function=$match[2][$i];
		    	// echo $_function.PHP_EOL;
		    	preg_match('/(.*?)\((.*?)\)/is',$_function,$m);
		    	if (isset($m[2])){
		    		$args=[];
		    		$function=$m[1];
		    		$args[0]=$google;
		    		$args[1]=$config;
		    		$args[2]=$wp_name;
		    		$_args=explode(',',$m[2]);
		    		foreach ($_args as $arg){
		    			$args[]=$arg;
		    		}
		    		
		    	}
		    	$rep=call_user_func_array($function, $args);
		    	// echo $rep.PHP_EOL;
		    	$top_content=str_replace('__func__'.$_function.'__endfunc__',$rep,$top_content);
		    	
		    }
	    }
	    
	    
	    


	    //parse bottom content
	    $bottom_content=$config['wp']['wp_post_template'][$wp_name]['bottom_content'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['bottom_content'],$match);
	    foreach ($match[1] as $m){
	        $ele=$m;
	        $bottom_content=str_replace('{'.$m.'}',$google->{$m},$bottom_content);
	    }
	    $bottom_content=html_entity_decode($bottom_content);
	    preg_match_all('/(.*?)__func__(.*?)__endfunc__(.*)/is',$bottom_content,$match);
	    // $rep='';
	    for ($i=0;$i<count($match[2]);$i++){
	    	if (isset($match[2][$i])){
		    	$_function=$match[2][$i];
		    	// echo $_function.PHP_EOL;
		    	preg_match('/(.*?)\((.*?)\)/is',$_function,$m);
		    	if (isset($m[2])){
		    		$args=[];
		    		$function=$m[1];
		    		$args[0]=$google;
		    		$args[1]=$config;
		    		$args[2]=$wp_name;
		    		$_args=explode(',',$m[2]);
		    		foreach ($_args as $arg){
		    			$args[]=$arg;
		    		}
		    		
		    	}
		    	$rep=call_user_func_array($function, $args);
		    	// echo $rep.PHP_EOL;
		    	$bottom_content=str_replace('__func__'.$_function.'__endfunc__',$rep,$bottom_content);
		    	
		    }
	    }

	    


	    //parse results array to text
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['results'],$match);    
	    $results='';

	    foreach ($google->results as $result){
	        $_content=$config['wp']['wp_post_template'][$wp_name]['results'];
	        $result=(object)$result;
	        foreach ($match[1] as $m){
	            $vars=vars($google);
	            $ele=$m;
	            if (isset($result->{$ele})){
	                $rep=$result->{$ele};
	            } else {
	                if (isset($vars->{$ele})){
	                    $rep=$vars->{$ele};
	                } else {
	                    $rep='';
	                }
	                
	            }
	            
	            $_content=str_replace('{'.$m.'}',$rep,$_content);
	            
	        }
	        $results.=$_content;
	    }


	    //parse paas array to text
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['paas'],$match);    
	    $paas='';
	    foreach ($google->paas as $result){
	        $_content=$config['wp']['wp_post_template'][$wp_name]['paas'];
	        $result=(object)$result;
	        foreach ($match[1] as $m){
	            $ele=$m;
	            $$m=$result->{$ele};
	            $_content=str_replace('{'.$m.'}',$$m,$_content);
	        }
	        $paas.=$_content;
	    }

	    //parse videos array to text
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['videos'],$match);
	    $videos='';
	    foreach ($google->videos as $result){
	        $_content=$config['wp']['wp_post_template'][$wp_name]['videos'];
	        $result=(object)$result;
	        foreach ($match[1] as $m){
	            $ele=$m;
	            $$m=$result->{$ele};
	            $_content=str_replace('{'.$m.'}',$$m,$_content);
	        }
	        $videos.=$_content;
	    }


	    


	    //excerpt
	    $description=$config['wp']['wp_post_template'][$wp_name]['description'];
	    $params=preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['description'],$match);
	    foreach ($match[1] as $m){
	        $ele=$m;
	        $description=str_replace('{'.$m.'}',$google->{$m},$description);
	    }
	    $description=html_entity_decode($description);
	    preg_match_all('/(.*?)__func__(.*?)__endfunc__(.*)/is',$description,$match);
	    // $rep='';
	    for ($i=0;$i<count($match[2]);$i++){
	    	if (isset($match[2][$i])){
		    	$_function=$match[2][$i];
		    	// echo $_function.PHP_EOL;
		    	preg_match('/(.*?)\((.*?)\)/is',$_function,$m);
		    	if (isset($m[2])){
		    		$args=[];
		    		$function=$m[1];
		    		$args[0]=$google;
		    		$args[1]=$config;
		    		$args[2]=$wp_name;
		    		$_args=explode(',',$m[2]);
		    		foreach ($_args as $arg){
		    			$args[]=$arg;
		    		}
		    		
		    	}
		    	$rep=call_user_func_array($function, $args);
		    	// echo $rep.PHP_EOL;
		    	$description=str_replace('__func__'.$_function.'__endfunc__',$rep,$description);
		    	
		    }
	    }
	    

	   
	    //category
	    $category=$config['wp']['wp_post_template'][$wp_name]['category'];


	    //title
	    preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['title'],$match);
	    $title=$config['wp']['wp_post_template'][$wp_name]['title'];

	    foreach ($match[1] as $m){
	    	if (isset($google->{$m})){
		    	$title=str_replace('{'.$m.'}',$google->{$m},$title);
		    } else {
		    	$vars=vars($google);
		    	
		    	if (isset($vars->{$m})){
		    		$title=str_replace('{'.$m.'}',$vars->{$m},$title);
		    	}
		    }
	    }
	    preg_match_all('/__func__(.*?)__endfunc__/is',$title,$match);
	    // $rep='';
	    for ($i=0;$i<count($match[1]);$i++){
	    	if (isset($match[1][$i])){
		    	$_function=$match[1][$i];
		    	// echo $_function.PHP_EOL;
		    	preg_match('/(.*?)\((.*?)\)/is',$_function,$m);
		    	if (isset($m[2])){
		    		$args=[];
		    		$function=$m[1];
		    		$args[0]=$google;
		    		$args[1]=$config;
		    		$args[2]=$wp_name;
		    		$_args=explode(',',$m[2]);
		    		foreach ($_args as $arg){
		    			$args[]=$arg;
		    		}
		    		
		    	}
		    	
		    	$rep=call_user_func_array($function, $args);
		    	// echo $rep.PHP_EOL;
		    	$title=str_replace('__func__'.$_function.'__endfunc__',$rep,$title);
		    	
		    }
	    }



			    
	    

	    //tags
	    $wp_keywords=$config['wp']['wp_post_template'][$wp_name]['tags'];
	    $wp_keywords=str_replace(['{','}'],'',$wp_keywords);
	    if (isset($google->{$wp_keywords})){
	        $wp_keywords=$google->{$wp_keywords};
	    }


	    //parse details content to one
	    preg_match('/(.*?)__func__(.*?)__endfunc__(.*)/is',$config['wp']['wp_post_template'][$wp_name]['mix'],$match);
	    if (isset($match[2])){
			
	    	$_function=$match[2];
	    	// echo $_function.PHP_EOL;
	    	preg_match('/(.*?)\((.*?)\)/is',$_function,$m);
	    	if (isset($m[2])){
	    		$args=[];
	    		$function=$m[1];
	    		$_args=explode(',',$m[2]);
	    		// print_r($_args);
	    		$args[0]=$google;
	    		$args[1]=$config;
	    		$args[2]=$wp_name;
	    		foreach ($_args as $arg){
	    			$args[]=$arg;
	    		}
	    	}
	    	// print_r($args);die();
	    	$rep=call_user_func_array($function, $args);
	    	// echo $rep.PHP_EOL;
	    	$mix=str_replace('__func__'.$_function.'__endfunc__',$rep,$config['wp']['wp_post_template'][$wp_name]['mix']);
		    
	    } else {
	    	preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['mix'],$match);
		    $mix='';
		    foreach ($google->results as $result){
		        $_mix=$config['wp']['wp_post_template'][$wp_name]['mix'];
		        $result=(object)$result;
		        foreach ($match[1] as $m){
		            $vars=vars($google);
		            $ele=$m;

		            if (isset($result->{$ele})){
		                $replace_content=$result->{$ele};
		            } else {
		                if (isset($vars->{$ele})){
		                    $replace_content=$vars->{$ele};
		                } else {
		                    if (strpos($ele,'|')!==false){
				            	$ex=explode('|',$ele);
				            	$ele=$ex[0];
				            	preg_match('/(.*?)\((.*?)\)(.*)/is',$ex[1],$mm);
							    $q=explode(',',$mm[2]);
							    $num=call_user_func_array($mm[1],$q);
							    if (isset($result->{$ele})){
							    	$content=$result->{$ele};
				            		eval('$replace_content=$php->trim_words($content,$num);');
				            	} else {
				            		$replace_content='';
				            	}
				            }
		                }
		            }
		            
		            $_mix=str_replace('{'.$m.'}',$replace_content,$_mix);
		            
		        }
		        $mix.=$_mix;
		    }
	    }
	    
	    
	    // echo $details;die();
	    //parse content from all
	    preg_match_all('/\[(.*?)\]/is',$config['wp']['wp_post_template'][$wp_name]['content'],$match);

	    $content=$config['wp']['wp_post_template'][$wp_name]['content'];
	    foreach ($match[1] as $m){
	        if (isset($$m)){
	            $content=str_replace('['.$m.']',$$m,$content);
	        }
	    }



	    $info->videos=$videos;
	    $info->mix=$mix;
	    $info->paas=$paas;
	    $info->results=$results;
	    $info->top_content=$top_content;
	    $info->bottom_content=$bottom_content;
	    $info->title=$title;
	    $info->description=$description;
	    $info->tags=$wp_keywords;
	    $info->category=$category;
	    $info->content=$content;
	    return $info;
	}


