<?php
	require_once(__DIR__ .'/qclass/quyet.class.php');
	
	//Ham nay lay ngau nhien 1 dong trong file $filename
	function random_from_file($google,$config,$wp_name,$filename){
		$lines=array_filter(file(__DIR__.'/'.$filename,FILE_IGNORE_NEW_LINES|FILE_SKIP_EMPTY_LINES));
		shuffle($lines);
		return $lines[0];
	}

	function get_element($google,$config,$wp_name,$ele=''){
		preg_match('/(.*?)\[(.*)/is',$ele,$m);
		// print_r($m);die();
		$element=$ele;
		if (isset($m[1])){
			$element=$m[1];
		}

		$_element=$google->{$element};
		preg_match_all('/\[(.*?)\]/is',$ele,$match);
		if (isset($match[1])){
			foreach ($match[1] as $m){
				if (is_numeric($m)){
					$_element=$_element[$m];
				} else {
					$_element=$_element["$m"];
				}
			}
		}
		
		return $_element;

	}

	function basic_mix($google,$config,$wp_name,$from,$to=100,$videos=null,$images=null){
		$php=new QuyetPHP();
		$results=$google->results;
		$results=array_slice($results,$from,$to);
		$content='';
		
		preg_match_all('/\{(.*?)\}/is',$config['wp']['wp_post_template'][$wp_name]['mix_template'],$match);
	    $mix='';
	    foreach ($results as $result){
	        $_mix=$config['wp']['wp_post_template'][$wp_name]['mix_template'];
	        $result=(object)$result;
	        foreach ($match[1] as $m){
	            $vars=vars($google);
	            $ele=$m;

	            if (isset($result->{$ele})){
	                $replace_content=$result->{$ele};
	            } else {
	                if (isset($vars->{$ele})){
	                    $replace_content=$vars->{$ele};
	                } else {
	                    if (strpos($ele,'|')!==false){
			            	$ex=explode('|',$ele);
			            	$ele=$ex[0];
			            	preg_match('/(.*?)\((.*?)\)(.*)/is',$ex[1],$mm);
						    $q=explode(',',$mm[2]);
						    $num=call_user_func_array($mm[1],$q);
						    if (isset($result->{$ele})){
						    	$content=$result->{$ele};
			            		eval('$replace_content=$php->trim_words($content,$num);');
			            	} else {
			            		$replace_content='';
			            	}
			            }
	                }
	            }
	            
	            $_mix=str_replace('{'.$m.'}',$replace_content,$_mix);
	            
	        }
	        $mix.=$_mix.'<span></span>';
	    }
	    $mix=substr($mix,0,-13);

	    if (!is_null($videos)){
	    	$videos=str_replace(';',',',$videos);
	    	preg_match('/(.*?)\[(.*?)\](.*)/is',$videos,$match);
	    	$videos=explode(',',$match[2]);
	    	$num=(int)str_replace('num=','',$videos[0]);
	    	$pos=str_replace('video_pos=','',$videos[1]);
	    	$videos=$google->videos;
	    	if (isset($videos[0])){
	    		shuffle($videos);
		    	$videos=array_slice($videos,0,$num);
		    	$video_html='';
		    	foreach ($videos as $video){
		    		$video_html.='<iframe class="video" src="https://www.youtube.com/embed/'.$video['ytid'].'" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope;" allowfullscreen></iframe><br><span>'.$video['title'].'</span><br>';
		    	}
		    	if ($pos=='first'){
		    		$mix=$video_html.'<br>'.$mix;
		    	} elseif ($pos=='last'){
		    		$mix=$mix.'<br>'.$video_html;
		    	} else {
		    		$needle = "<span></span>";
				    $lastPos = 0;
				    $positions = array();

				    while (($lastPos = strpos($mix, $needle, $lastPos))!== false) {
				        $positions[] = $lastPos;
				        $lastPos = $lastPos + strlen($needle);
				    }

				    
			    	$pos=rand(1,count($positions)-2);
			    	$mix=substr_replace($mix, $video_html.'<span></span>', $positions[$pos] , 13);
				
		    	}
	    	}
	    	
	    }

	    if (!is_null($images)){
	    	
	    	$images=str_replace(';',',',$images);
	    	preg_match('/(.*?)\[(.*?)\](.*)/is',$images,$match);
	    	
	    	$images=explode(',',$match[2]);
	    	$num=(int)str_replace('num=','',$images[0]);
	    	$pos=str_replace('image_pos=','',$images[1]);
	    	$images=$google->image_results;
	    	if (isset($images[0])){
				shuffle($images);
		    	$images=array_slice($images,0,$num);
		    	$image_html='';
		    	foreach ($images as $image){
		    		$image_html.='<img src="'.$image.'" /><br>';
		    	}
		    	if ($pos=='first'){
		    		$mix=$image_html.'<br>'.$mix;
		    	} elseif ($pos=='last'){
		    		$mix=$mix.'<br>'.$image_html;
		    	} else {
		    		
		    		$needle = "<span></span>";
				    $lastPos = 0;
				    $positions = array();

				    while (($lastPos = strpos($mix, $needle, $lastPos))!== false) {
				        $positions[] = $lastPos;
				        $lastPos = $lastPos + strlen($needle);
				    }

				    
			    	$pos=rand(1,count($positions)-2);
			    	$mix=substr_replace($mix, $image_html.'<span></span>', $positions[$pos] , 13);
			    
		    	}
	    	}
	    	
	    }


	    return str_replace('<span></span>','',$mix);
	}


