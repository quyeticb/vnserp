<?php
	require_once(__DIR__ .'/vendor/autoload.php');
	use fivefilters\Readability\Readability;
	use fivefilters\Readability\Configuration;
	use fivefilters\Readability\ParseException;

	$readability = new Readability(new Configuration());

	$html = file_get_contents('https://www.betterhostreview.com/turn-on-reader-mode-chrome-web-browser.html');

	try {
	    $readability->parse($html);
	    echo $readability;
	} catch (ParseException $e) {
	    echo sprintf('Error processing text: %s', $e->getMessage());
	}