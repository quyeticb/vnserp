<?php
	require_once(__DIR__ .'/encoding.php');
	use \ForceUTF8\Encoding;

	class QuyetPHP {
		public $guzzle;
		public $cookies;
		public function __construct(){}
		public function string_to_hex($string){
		    $hex = '';
		    for ($i=0; $i<strlen($string); $i++){
		        $ord = ord($string[$i]);
		        $hexCode = dechex($ord);
		        $hex .= substr('0'.$hexCode, -2);
		    }
		    return strToUpper($hex);
		}
		public function hex_to_string($hex){
		    $string='';
		    for ($i=0; $i < strlen($hex)-1; $i+=2){
		        $string .= chr(hexdec($hex[$i].$hex[$i+1]));
		    }
		    return $string;
		}
		public function fix_utf8($str){
			return Encoding::fixUTF8($str);
		}
		public function rand_str($length = 10) {
		    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		    $charactersLength = strlen($characters);
		    $randomString = '';
		    for ($i = 0; $i < $length; $i++) {
		        $randomString .= $characters[rand(0, $charactersLength - 1)];
		    }
		    return $randomString;
		}
		public function microtime_float() {
			list($usec, $sec) = explode(" ", microtime());
			return ((float)$usec + (float)$sec);
		}
		public function time_ago($datetime, $full = false) {
			$now = new DateTime;
			try {
				$ago = new DateTime($datetime);
				$diff = $now->diff($ago);

				$diff->w = floor($diff->d / 7);
				$diff->d -= $diff->w * 7;

				$string = array(
					'y' => 'year',
					'm' => 'month',
					'w' => 'week',
					'd' => 'day',
					'h' => 'hour',
					'i' => 'minute',
					's' => 'second',
				);
				foreach ($string as $k => &$v) {
					if ($diff->$k) {
						$v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
					} else {
						unset($string[$k]);
					}
				}

				if (!$full) $string = array_slice($string, 0, 1);
				return $string ? implode(', ', $string) . ' ago' : 'just now';
			} catch (Exception $e){
				return 'Unknown';
			}
		}
		public function bom_to_utf8($text) {
		    $map = array(
		        chr(0x8A) => chr(0xA9),
		        chr(0x8C) => chr(0xA6),
		        chr(0x8D) => chr(0xAB),
		        chr(0x8E) => chr(0xAE),
		        chr(0x8F) => chr(0xAC),
		        chr(0x9C) => chr(0xB6),
		        chr(0x9D) => chr(0xBB),
		        chr(0xA1) => chr(0xB7),
		        chr(0xA5) => chr(0xA1),
		        chr(0xBC) => chr(0xA5),
		        chr(0x9F) => chr(0xBC),
		        chr(0xB9) => chr(0xB1),
		        chr(0x9A) => chr(0xB9),
		        chr(0xBE) => chr(0xB5),
		        chr(0x9E) => chr(0xBE),
		        chr(0x80) => '&euro;',
		        chr(0x82) => '&sbquo;',
		        chr(0x84) => '&bdquo;',
		        chr(0x85) => '&hellip;',
		        chr(0x86) => '&dagger;',
		        chr(0x87) => '&Dagger;',
		        chr(0x89) => '&permil;',
		        chr(0x8B) => '&lsaquo;',
		        chr(0x91) => '&lsquo;',
		        chr(0x92) => '&rsquo;',
		        chr(0x93) => '&ldquo;',
		        chr(0x94) => '&rdquo;',
		        chr(0x95) => '&bull;',
		        chr(0x96) => '&ndash;',
		        chr(0x97) => '&mdash;',
		        chr(0x99) => '&trade;',
		        chr(0x9B) => '&rsquo;',
		        chr(0xA6) => '&brvbar;',
		        chr(0xA9) => '&copy;',
		        chr(0xAB) => '&laquo;',
		        chr(0xAE) => '&reg;',
		        chr(0xB1) => '&plusmn;',
		        chr(0xB5) => '&micro;',
		        chr(0xB6) => '&para;',
		        chr(0xB7) => '&middot;',
		        chr(0xBB) => '&raquo;',
		    );
		    return html_entity_decode(mb_convert_encoding(strtr($text, $map), 'UTF-8','ISO-8859-2'), ENT_QUOTES, 'UTF-8');
		}
		public function remove_bom($text) {
		    $bom = pack('H*','EFBBBF');
		    $text = preg_replace("/^$bom/", '', $text);
		    return $text;
		}
		
		
		public function googleJSToUTF8($str) {
			$str = preg_replace_callback('/\\\\u([0-9a-fA-F]{4})/', function ($match) {
				return mb_convert_encoding(pack('H*', $match[1]), 'UTF-8', 'UCS-2BE');
			}, $str);
			return $str;
		}
		public function mb_trim( $str ) {
		    return mb_ereg_replace(
		        '^[[:space:]]*([\s\S]*?)[[:space:]]*$', '\1', $str );
		}
		public function clean_html($html) {
			ob_start();
			$config = array(
				'clean' => true,
				'output-xhtml' => false,
				'show-body-only' => true,
				'wrap'  => 200
			);
			$tidy = new tidy;
			$tidy->parseString($html, $config, 'utf8');
			$tidy->cleanRepair();
			return $tidy->value;
		}
		public function clean_html_other($html) {
			$szPostContent = $html;
			$szRemoveFilter = array( "~<p[^>]*>s?</p>~", "~<a[^>]*>s?</a>~", "~<font[^>]*>~", "~</font>~", "~<span[^>]*>s?</span>~" );
			$szPostContent = preg_replace( $szRemoveFilter, '' , $szPostContent);
			$szPostContent = htmLawed($szPostContent);
			return $szPostContent;
		}
		public function time_format($seconds) {
			$hours=0;
			$milliseconds=str_replace("0.",'',$seconds-floor($seconds));
			if ($seconds>3600) {
				$hours=floor($seconds/3600);
			}
			$seconds=$seconds%3600;
			return str_pad($hours,2,'0',STR_PAD_LEFT).gmdate(':i:s',$seconds).($milliseconds ? ".$milliseconds":'');
		}
		public function int_format_str($n,$precision = 1){
			if ($n < 900) {
				// 0 - 900
				$n_format = number_format($n, $precision);
				$suffix = '';
			} else if ($n < 900000) {
				// 0.9k-850k
				$n_format = number_format($n / 1000, $precision);
				$suffix = 'K';
			} else if ($n < 900000000) {
				// 0.9m-850m
				$n_format = number_format($n / 1000000, $precision);
				$suffix = 'M';
			} else if ($n < 900000000000) {
				// 0.9b-850b
				$n_format = number_format($n / 1000000000, $precision);
				$suffix = 'B';
			} else {
				// 0.9t+
				$n_format = number_format($n / 1000000000000, $precision);
				$suffix = 'T';
			}

		  // Remove unecessary zeroes after decimal. "1.0" -> "1"; "1.00" -> "1"
		  // Intentionally does not affect partials, eg "1.50" -> "1.50"
			if ( $precision > 0 ) {
				$dotzero = '.' . str_repeat( '0', $precision );
				$n_format = str_replace( $dotzero, '', $n_format );
			}

			return $n_format . $suffix;
		}
		public function size_format($bytes) {
	        if ($bytes >= 1073741824) {
	            $bytes=number_format($bytes/1073741824, 2).' GB';
	        } elseif ($bytes >= 1048576) {
	            $bytes=number_format($bytes/1048576, 2).' MB';
	        } elseif ($bytes >= 1024) {
	            $bytes=number_format($bytes/1024,2).' KB';
	        } elseif ($bytes > 1) {
	            $bytes=$bytes.'b';
	        } elseif ($bytes==1) {
	            $bytes=$bytes.'b';
	        } else {
	            $bytes='0 b';
	        }
	        return $bytes;
		}
		public function output_compress($buffer) {
			$search=['/\>[^\S ]+/s','/[^\S ]+\</s','/(\s)+/s'];
			$replace=['>','<','\\1'];
			$buffer = preg_replace($search, $replace, $buffer);
			$buffer=preg_replace('/<\!\-\-(.*?)\-\->/is','',$buffer);
			return $buffer;
		}
		
		
		public function trim_char($string,$length=100,$append="") {
			$string = trim($string);
			if(strlen($string) > $length) {
			$string = wordwrap($string, $length);
			$string = explode("\n",$string);
			$string = array_shift($string) . $append;
			}
			return $string;
		}
		public function remove_accents($string,$locale='en_US') {
			if ( !preg_match('/[\x80-\xff]/', $string) )
				return $string;

			if ($this->seems_utf8($string)) {
				$chars = array(
				// Decompositions for Latin-1 Supplement
				'ª' => 'a', 'º' => 'o',
				'À' => 'A', 'Á' => 'A',
				'Â' => 'A', 'Ã' => 'A',
				'Ä' => 'A', 'Å' => 'A',
				'Æ' => 'AE','Ç' => 'C',
				'È' => 'E', 'É' => 'E',
				'Ê' => 'E', 'Ë' => 'E',
				'Ì' => 'I', 'Í' => 'I',
				'Î' => 'I', 'Ï' => 'I',
				'Ð' => 'D', 'Ñ' => 'N',
				'Ò' => 'O', 'Ó' => 'O',
				'Ô' => 'O', 'Õ' => 'O',
				'Ö' => 'O', 'Ù' => 'U',
				'Ú' => 'U', 'Û' => 'U',
				'Ü' => 'U', 'Ý' => 'Y',
				'Þ' => 'TH','ß' => 's',
				'à' => 'a', 'á' => 'a',
				'â' => 'a', 'ã' => 'a',
				'ä' => 'a', 'å' => 'a',
				'æ' => 'ae','ç' => 'c',
				'è' => 'e', 'é' => 'e',
				'ê' => 'e', 'ë' => 'e',
				'ì' => 'i', 'í' => 'i',
				'î' => 'i', 'ï' => 'i',
				'ð' => 'd', 'ñ' => 'n',
				'ò' => 'o', 'ó' => 'o',
				'ô' => 'o', 'õ' => 'o',
				'ö' => 'o', 'ø' => 'o',
				'ù' => 'u', 'ú' => 'u',
				'û' => 'u', 'ü' => 'u',
				'ý' => 'y', 'þ' => 'th',
				'ÿ' => 'y', 'Ø' => 'O',
				// Decompositions for Latin Extended-A
				'Ā' => 'A', 'ā' => 'a',
				'Ă' => 'A', 'ă' => 'a',
				'Ą' => 'A', 'ą' => 'a',
				'Ć' => 'C', 'ć' => 'c',
				'Ĉ' => 'C', 'ĉ' => 'c',
				'Ċ' => 'C', 'ċ' => 'c',
				'Č' => 'C', 'č' => 'c',
				'Ď' => 'D', 'ď' => 'd',
				'Đ' => 'D', 'đ' => 'd',
				'Ē' => 'E', 'ē' => 'e',
				'Ĕ' => 'E', 'ĕ' => 'e',
				'Ė' => 'E', 'ė' => 'e',
				'Ę' => 'E', 'ę' => 'e',
				'Ě' => 'E', 'ě' => 'e',
				'Ĝ' => 'G', 'ĝ' => 'g',
				'Ğ' => 'G', 'ğ' => 'g',
				'Ġ' => 'G', 'ġ' => 'g',
				'Ģ' => 'G', 'ģ' => 'g',
				'Ĥ' => 'H', 'ĥ' => 'h',
				'Ħ' => 'H', 'ħ' => 'h',
				'Ĩ' => 'I', 'ĩ' => 'i',
				'Ī' => 'I', 'ī' => 'i',
				'Ĭ' => 'I', 'ĭ' => 'i',
				'Į' => 'I', 'į' => 'i',
				'İ' => 'I', 'ı' => 'i',
				'Ĳ' => 'IJ','ĳ' => 'ij',
				'Ĵ' => 'J', 'ĵ' => 'j',
				'Ķ' => 'K', 'ķ' => 'k',
				'ĸ' => 'k', 'Ĺ' => 'L',
				'ĺ' => 'l', 'Ļ' => 'L',
				'ļ' => 'l', 'Ľ' => 'L',
				'ľ' => 'l', 'Ŀ' => 'L',
				'ŀ' => 'l', 'Ł' => 'L',
				'ł' => 'l', 'Ń' => 'N',
				'ń' => 'n', 'Ņ' => 'N',
				'ņ' => 'n', 'Ň' => 'N',
				'ň' => 'n', 'ŉ' => 'n',
				'Ŋ' => 'N', 'ŋ' => 'n',
				'Ō' => 'O', 'ō' => 'o',
				'Ŏ' => 'O', 'ŏ' => 'o',
				'Ő' => 'O', 'ő' => 'o',
				'Œ' => 'OE','œ' => 'oe',
				'Ŕ' => 'R','ŕ' => 'r',
				'Ŗ' => 'R','ŗ' => 'r',
				'Ř' => 'R','ř' => 'r',
				'Ś' => 'S','ś' => 's',
				'Ŝ' => 'S','ŝ' => 's',
				'Ş' => 'S','ş' => 's',
				'Š' => 'S', 'š' => 's',
				'Ţ' => 'T', 'ţ' => 't',
				'Ť' => 'T', 'ť' => 't',
				'Ŧ' => 'T', 'ŧ' => 't',
				'Ũ' => 'U', 'ũ' => 'u',
				'Ū' => 'U', 'ū' => 'u',
				'Ŭ' => 'U', 'ŭ' => 'u',
				'Ů' => 'U', 'ů' => 'u',
				'Ű' => 'U', 'ű' => 'u',
				'Ų' => 'U', 'ų' => 'u',
				'Ŵ' => 'W', 'ŵ' => 'w',
				'Ŷ' => 'Y', 'ŷ' => 'y',
				'Ÿ' => 'Y', 'Ź' => 'Z',
				'ź' => 'z', 'Ż' => 'Z',
				'ż' => 'z', 'Ž' => 'Z',
				'ž' => 'z', 'ſ' => 's',
				// Decompositions for Latin Extended-B
				'Ș' => 'S', 'ș' => 's',
				'Ț' => 'T', 'ț' => 't',
				// Euro Sign
				'€' => 'E',
				// GBP (Pound) Sign
				'£' => '',
				// Vowels with diacritic (Vietnamese)
				// unmarked
				'Ơ' => 'O', 'ơ' => 'o',
				'Ư' => 'U', 'ư' => 'u',
				// grave accent
				'Ầ' => 'A', 'ầ' => 'a',
				'Ằ' => 'A', 'ằ' => 'a',
				'Ề' => 'E', 'ề' => 'e',
				'Ồ' => 'O', 'ồ' => 'o',
				'Ờ' => 'O', 'ờ' => 'o',
				'Ừ' => 'U', 'ừ' => 'u',
				'Ỳ' => 'Y', 'ỳ' => 'y',
				// hook
				'Ả' => 'A', 'ả' => 'a',
				'Ẩ' => 'A', 'ẩ' => 'a',
				'Ẳ' => 'A', 'ẳ' => 'a',
				'Ẻ' => 'E', 'ẻ' => 'e',
				'Ể' => 'E', 'ể' => 'e',
				'Ỉ' => 'I', 'ỉ' => 'i',
				'Ỏ' => 'O', 'ỏ' => 'o',
				'Ổ' => 'O', 'ổ' => 'o',
				'Ở' => 'O', 'ở' => 'o',
				'Ủ' => 'U', 'ủ' => 'u',
				'Ử' => 'U', 'ử' => 'u',
				'Ỷ' => 'Y', 'ỷ' => 'y',
				// tilde
				'Ẫ' => 'A', 'ẫ' => 'a',
				'Ẵ' => 'A', 'ẵ' => 'a',
				'Ẽ' => 'E', 'ẽ' => 'e',
				'Ễ' => 'E', 'ễ' => 'e',
				'Ỗ' => 'O', 'ỗ' => 'o',
				'Ỡ' => 'O', 'ỡ' => 'o',
				'Ữ' => 'U', 'ữ' => 'u',
				'Ỹ' => 'Y', 'ỹ' => 'y',
				// acute accent
				'Ấ' => 'A', 'ấ' => 'a',
				'Ắ' => 'A', 'ắ' => 'a',
				'Ế' => 'E', 'ế' => 'e',
				'Ố' => 'O', 'ố' => 'o',
				'Ớ' => 'O', 'ớ' => 'o',
				'Ứ' => 'U', 'ứ' => 'u',
				// dot below
				'Ạ' => 'A', 'ạ' => 'a',
				'Ậ' => 'A', 'ậ' => 'a',
				'Ặ' => 'A', 'ặ' => 'a',
				'Ẹ' => 'E', 'ẹ' => 'e',
				'Ệ' => 'E', 'ệ' => 'e',
				'Ị' => 'I', 'ị' => 'i',
				'Ọ' => 'O', 'ọ' => 'o',
				'Ộ' => 'O', 'ộ' => 'o',
				'Ợ' => 'O', 'ợ' => 'o',
				'Ụ' => 'U', 'ụ' => 'u',
				'Ự' => 'U', 'ự' => 'u',
				'Ỵ' => 'Y', 'ỵ' => 'y',
				// Vowels with diacritic (Chinese, Hanyu Pinyin)
				'ɑ' => 'a',
				// macron
				'Ǖ' => 'U', 'ǖ' => 'u',
				// acute accent
				'Ǘ' => 'U', 'ǘ' => 'u',
				// caron
				'Ǎ' => 'A', 'ǎ' => 'a',
				'Ǐ' => 'I', 'ǐ' => 'i',
				'Ǒ' => 'O', 'ǒ' => 'o',
				'Ǔ' => 'U', 'ǔ' => 'u',
				'Ǚ' => 'U', 'ǚ' => 'u',
				// grave accent
				'Ǜ' => 'U', 'ǜ' => 'u',
				);

				// Used for locale-specific rules

				if ( 'de_DE' == $locale || 'de_DE_formal' == $locale || 'de_CH' == $locale || 'de_CH_informal' == $locale ) {
					$chars[ 'Ä' ] = 'Ae';
					$chars[ 'ä' ] = 'ae';
					$chars[ 'Ö' ] = 'Oe';
					$chars[ 'ö' ] = 'oe';
					$chars[ 'Ü' ] = 'Ue';
					$chars[ 'ü' ] = 'ue';
					$chars[ 'ß' ] = 'ss';
				} elseif ( 'da_DK' === $locale ) {
					$chars[ 'Æ' ] = 'Ae';
		 			$chars[ 'æ' ] = 'ae';
					$chars[ 'Ø' ] = 'Oe';
					$chars[ 'ø' ] = 'oe';
					$chars[ 'Å' ] = 'Aa';
					$chars[ 'å' ] = 'aa';
				} elseif ( 'ca' === $locale ) {
					$chars[ 'l·l' ] = 'll';
				} elseif ( 'sr_RS' === $locale || 'bs_BA' === $locale ) {
					$chars[ 'Đ' ] = 'DJ';
					$chars[ 'đ' ] = 'dj';
				}

				$string = strtr($string, $chars);
			} else {
				$chars = array();
				// Assume ISO-8859-1 if not UTF-8
				$chars['in'] = "\x80\x83\x8a\x8e\x9a\x9e"
					."\x9f\xa2\xa5\xb5\xc0\xc1\xc2"
					."\xc3\xc4\xc5\xc7\xc8\xc9\xca"
					."\xcb\xcc\xcd\xce\xcf\xd1\xd2"
					."\xd3\xd4\xd5\xd6\xd8\xd9\xda"
					."\xdb\xdc\xdd\xe0\xe1\xe2\xe3"
					."\xe4\xe5\xe7\xe8\xe9\xea\xeb"
					."\xec\xed\xee\xef\xf1\xf2\xf3"
					."\xf4\xf5\xf6\xf8\xf9\xfa\xfb"
					."\xfc\xfd\xff";

				$chars['out'] = "EfSZszYcYuAAAAAACEEEEIIIINOOOOOOUUUUYaaaaaaceeeeiiiinoooooouuuuyy";

				$string = strtr($string, $chars['in'], $chars['out']);
				$double_chars = array();
				$double_chars['in'] = array("\x8c", "\x9c", "\xc6", "\xd0", "\xde", "\xdf", "\xe6", "\xf0", "\xfe");
				$double_chars['out'] = array('OE', 'oe', 'AE', 'DH', 'TH', 'ss', 'ae', 'dh', 'th');
				$string = str_replace($double_chars['in'], $double_chars['out'], $string);
			}

			return $string;
		}
		public function seems_utf8( $str ) {
			$this->mbstring_binary_safe_encoding();
			$length = strlen($str);
			$this->reset_mbstring_encoding();
			for ($i=0; $i < $length; $i++) {
				$c = ord($str[$i]);
				if ($c < 0x80) $n = 0; // 0bbbbbbb
				elseif (($c & 0xE0) == 0xC0) $n=1; // 110bbbbb
				elseif (($c & 0xF0) == 0xE0) $n=2; // 1110bbbb
				elseif (($c & 0xF8) == 0xF0) $n=3; // 11110bbb
				elseif (($c & 0xFC) == 0xF8) $n=4; // 111110bb
				elseif (($c & 0xFE) == 0xFC) $n=5; // 1111110b
				else return false; // Does not match any model
				for ($j=0; $j<$n; $j++) { // n bytes matching 10bbbbbb follow ?
					if ((++$i == $length) || ((ord($str[$i]) & 0xC0) != 0x80))
						return false;
				}
			}
			return true;
		}
		public function mbstring_binary_safe_encoding( $reset = false ) {
		    static $encodings = array();
		    static $overloaded = null;
		 
		    if ( is_null( $overloaded ) )
		        $overloaded = function_exists( 'mb_internal_encoding' ) && ( ini_get( 'mbstring.func_overload' ) & 2 );
		 
		    if ( false === $overloaded )
		        return;
		 
		    if ( ! $reset ) {
		        $encoding = mb_internal_encoding();
		        array_push( $encodings, $encoding );
		        mb_internal_encoding( 'ISO-8859-1' );
		    }
		 
		    if ( $reset && $encodings ) {
		        $encoding = array_pop( $encodings );
		        mb_internal_encoding( $encoding );
		    }
		}
		public function reset_mbstring_encoding() {
		    $this->mbstring_binary_safe_encoding( true );
		}
		public function utf8_uri_encode( $utf8_string, $length = 0 ) {
			$unicode = '';
			$values = array();
			$num_octets = 1;
			$unicode_length = 0;

			$this->mbstring_binary_safe_encoding();
			$string_length = strlen( $utf8_string );
			$this->reset_mbstring_encoding();

			for ($i = 0; $i < $string_length; $i++ ) {

				$value = ord( $utf8_string[ $i ] );

				if ( $value < 128 ) {
					if ( $length && ( $unicode_length >= $length ) )
						break;
					$unicode .= chr($value);
					$unicode_length++;
				} else {
					if ( count( $values ) == 0 ) {
						if ( $value < 224 ) {
							$num_octets = 2;
						} elseif ( $value < 240 ) {
							$num_octets = 3;
						} else {
							$num_octets = 4;
						}
					}

					$values[] = $value;

					if ( $length && ( $unicode_length + ($num_octets * 3) ) > $length )
						break;
					if ( count( $values ) == $num_octets ) {
						for ( $j = 0; $j < $num_octets; $j++ ) {
							$unicode .= '%' . dechex( $values[ $j ] );
						}

						$unicode_length += $num_octets * 3;

						$values = array();
						$num_octets = 1;
					}
				}
			}

			return $unicode;
		}
		public function sanitize_title_with_dash( $title, $raw_title = '', $context = 'display' ) {
			$title = strip_tags($title);
			// Preserve escaped octets.
			$title = preg_replace('|%([a-fA-F0-9][a-fA-F0-9])|', '---$1---', $title);
			// Remove percent signs that are not part of an octet.
			$title = str_replace('%', '', $title);
			// Restore octets.
			$title = preg_replace('|---([a-fA-F0-9][a-fA-F0-9])---|', '%$1', $title);

			if ($this->seems_utf8($title)) {
				if (function_exists('mb_strtolower')) {
					$title = mb_strtolower($title, 'UTF-8');
				}
				$title = $this->utf8_uri_encode($title, 200);
			}

			$title = strtolower($title);

			if ( 'save' == $context ) {
				// Convert nbsp, ndash and mdash to hyphens
				$title = str_replace( array( '%c2%a0', '%e2%80%93', '%e2%80%94' ), '-', $title );
				// Convert nbsp, ndash and mdash HTML entities to hyphens
				$title = str_replace( array( '&nbsp;', '&#160;', '&ndash;', '&#8211;', '&mdash;', '&#8212;' ), '-', $title );
				// Convert forward slash to hyphen
				$title = str_replace( '/', '-', $title );

				// Strip these characters entirely
				$title = str_replace( array(
					// iexcl and iquest
					'%c2%a1', '%c2%bf',
					// angle quotes
					'%c2%ab', '%c2%bb', '%e2%80%b9', '%e2%80%ba',
					// curly quotes
					'%e2%80%98', '%e2%80%99', '%e2%80%9c', '%e2%80%9d',
					'%e2%80%9a', '%e2%80%9b', '%e2%80%9e', '%e2%80%9f',
					// copy, reg, deg, hellip and trade
					'%c2%a9', '%c2%ae', '%c2%b0', '%e2%80%a6', '%e2%84%a2',
					// acute accents
					'%c2%b4', '%cb%8a', '%cc%81', '%cd%81',
					// grave accent, macron, caron
					'%cc%80', '%cc%84', '%cc%8c',
				), '', $title );

				// Convert times to x
				$title = str_replace( '%c3%97', 'x', $title );
			}

			$title = preg_replace('/&.+?;/', '', $title); // kill entities
			$title = str_replace('.', '-', $title);

			$title = preg_replace('/[^%a-z0-9 _-]/', '', $title);
			$title = preg_replace('/\s+/', '-', $title);
			$title = preg_replace('|-+|', '-', $title);
			$title = trim($title, '-');

			return $title;
		}
		public function slug($title){
			return $this->sanitize_title_with_dash($this->remove_accents($title,'en_US'));
		}
		public function strip_all_tags($string, $remove_breaks = false) {
			$string = preg_replace( '@<(script|style)[^>]*?>.*?</\\1>@si', '', $string );
			$string = strip_tags($string);

			if ( $remove_breaks )
				$string = preg_replace('/[\r\n\t ]+/', ' ', $string);

			return trim( $string );
		}
		public function trim_words( $text, $num_words = 55, $more = null ) {
			if ( null === $more ) {
				$more = '...';
			}

			$original_text = $text;
			$text = $this->strip_all_tags( $text );
			$words_array = preg_split( "/[\n\r\t ]+/", $text, $num_words + 1, PREG_SPLIT_NO_EMPTY );
			$sep = ' ';
			if ( count( $words_array ) > $num_words ) {
				array_pop( $words_array );
				$text = implode( $sep, $words_array );
				$text = $text . $more;
			} else {
				$text = implode( $sep, $words_array );
			}

			return $text;
		}
		public function dom_load_doc($html){
			libxml_use_internal_errors(true);
			$doc=new DOMDocument('1.0', 'UTF-8');
			$doc->loadHTML('<meta http-equiv="Content-Type" content="text/html; charset=utf-8">'.$html);
			return $doc;
		}
		public function price_to_float($price){
		    $price = str_replace(',', '.', $price);
		    $price = preg_replace("/[^0-9\.]/", "", $price);
		    $price = str_replace('.', '',substr($price, 0, -3)) . substr($price, -3);

		    return (float) $price;
		}
		
	}
	